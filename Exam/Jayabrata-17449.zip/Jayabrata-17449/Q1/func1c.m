function out =myfunc(x)
out= x^3-6*x^2+11*x-6;
end

