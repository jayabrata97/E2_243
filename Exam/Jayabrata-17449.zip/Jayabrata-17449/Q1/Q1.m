clc
clear all

r=sqrt(5);
r1=rat(r)

n=fix(r)


    
