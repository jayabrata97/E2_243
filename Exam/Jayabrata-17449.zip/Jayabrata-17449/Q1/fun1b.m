function out= fun(x)
out=1-((1-(1+x+x^2)/(1+2*x+3*x^2))^2);
end
